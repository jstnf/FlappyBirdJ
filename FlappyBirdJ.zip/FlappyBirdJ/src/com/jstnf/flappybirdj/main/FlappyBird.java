package com.jstnf.flappybirdj.main;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;

import com.jstnf.flappybirdj.objects.Bird;
import com.jstnf.flappybirdj.objects.Grass;

public class FlappyBird extends Canvas implements Runnable {

	private static final long serialVersionUID = 1L;
	public static final int WIDTH = 400, HEIGHT = 600;

	private Thread thread;
	private boolean running;

	private Handler handler;

	protected Bird player;
	protected int score;

	protected int state; // 0 dead or menu, 1 hover, 2 playing

	public FlappyBird() {
		state = 1;
		score = 0;
		handler = new Handler(this);
		this.addKeyListener(new KeyInput(handler));
		new Window(WIDTH, HEIGHT, "FlappyBirdJ", this);

		player = new Bird(WIDTH / 4, (HEIGHT - 124) / 2, Entity.BIRD, handler);
		handler.addObject(player);
		handler.addObject(new Grass(0, (int) (HEIGHT * (200.0 / 256.0)), Entity.STATIC, handler));
	}

	public synchronized void start() {
		if (!running) {
			thread = new Thread(this);
			thread.start();
			running = true;
		}
		Assets.init();
	}

	public synchronized void stop() {
		try {
			thread.join();
			running = false;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		long lastTime = System.nanoTime();
		double amountOfTicks = 60.0;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;
		long timer = System.currentTimeMillis();
		int frames = 0;
		while (running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			while (delta >= 1) {
				tick();
				delta--;
			}
			if (running)
				render();
			frames++;

			if (System.currentTimeMillis() - timer > 1000) {
				timer += 1000;
				System.out.println("FPS: " + frames);
				frames = 0;
			}
		}
		stop();
	}

	private void tick() {
		handler.tick();
		// System.out.println("SCORE: " + getScore());
	}

	private void render() {
		BufferStrategy bs = this.getBufferStrategy();
		if (bs == null) {
			this.createBufferStrategy(3);
			return;
		}

		Graphics g = bs.getDrawGraphics();
		Graphics g2d = bs.getDrawGraphics();
		g.drawImage(Assets.bg, 0, 0, WIDTH, HEIGHT, null);

		handler.render(g, (Graphics2D) g2d);
		
		if (state == 1) {
			g.drawImage(Assets.directions, WIDTH / 2 - 63, HEIGHT / 2, null);
		}

		g.dispose();
		bs.show();
	}

	public static void main(String[] args) {
		new FlappyBird();
	}

	public void reset() {
		setScore(0);
		setState(1);
		Assets.play(Assets.swooshing);
		handler.reset();
		getPlayer().reset();
	}

	// Getters/Setters
	public Bird getPlayer() {
		return player;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int newScore) {
		score = newScore;
		System.out.println("Score: " + score);
	}

	public int getState() {
		return state;
	}

	public void setState(int newState) {
		state = newState;
	}

}
