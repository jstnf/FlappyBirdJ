package com.jstnf.flappybirdj.main;

public enum Entity {

	BIRD(),
	PIPE(),
	STATIC();
	
}
